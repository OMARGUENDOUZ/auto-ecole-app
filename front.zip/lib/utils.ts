import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Student } from '../types/candidat';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date, formatStr = 'dd/MM/yyyy'): string {
  return format(new Date(date), formatStr, { locale: fr });
}

export function formatPhoneNumber(phone: string): string {
  return phone.replace(/(\d{2})(?=\d)/g, '$1 ');
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    REGISTERED: 'Inscrit',
    IN_TRAINING: 'En Formation',
    READY_FOR_EXAM: 'Prêt Examen',
    EXAM_SCHEDULED: 'Examen Planifié',
    LICENSED: 'Permis Obtenu',
    DROPPED_OUT: 'Abandonné'
  };
  return labels[status] || status;
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    REGISTERED: 'bg-blue-100 text-blue-800',
    IN_TRAINING: 'bg-yellow-100 text-yellow-800',
    READY_FOR_EXAM: 'bg-purple-100 text-purple-800',
    EXAM_SCHEDULED: 'bg-orange-100 text-orange-800',
    LICENSED: 'bg-green-100 text-green-800',
    DROPPED_OUT: 'bg-red-100 text-red-800'
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
}

export function calculateProgress(student: Student): number {
  // Logique basique: REGISTERED=0%, IN_TRAINING=40%, READY_FOR_EXAM=70%, EXAM_SCHEDULED=85%, LICENSED=100%
  const progressMap: Record<string, number> = {
    REGISTERED: 10,
    IN_TRAINING: 40,
    READY_FOR_EXAM: 70,
    EXAM_SCHEDULED: 85,
    LICENSED: 100,
    DROPPED_OUT: 0
  };
  return progressMap[student.status] || 0;
}
