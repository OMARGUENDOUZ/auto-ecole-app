﻿'use client';

import { Suspense } from 'react';
import dynamic from 'next/dynamic';

const CandidatDetailContent = dynamic(() => import('@/components/candidats/CandidatDetailContent'), {
  loading: () => <div className="text-center py-8">Chargement du profil...</div>,
  ssr: false,
});

export default function CandidatDetailPage() {
  return (
    <div className="space-y-6">
      <Suspense fallback={<div>Chargement...</div>}>
        <CandidatDetailContent />
      </Suspense>
    </div>
  );
}
