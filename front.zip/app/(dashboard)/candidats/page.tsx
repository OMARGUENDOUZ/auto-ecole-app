﻿'use client';

import dynamic from 'next/dynamic';

const CandidatsListContent = dynamic(() => import('@/components/candidats/CandidatsListContent').then(mod => ({ default: mod.CandidatsListContent })), {
  loading: () => <div className="text-center py-8">Chargement des candidats...</div>,
  ssr: false,
});

export default function CandidatsPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Candidats</h1>
      </div>
      <CandidatsListContent />
    </div>
  );
}
