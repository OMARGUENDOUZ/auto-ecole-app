import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Auto-École Manager",
  description: "Gestion complète pour auto-écoles",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
