'use client';

import { useParams, useRouter } from 'next/navigation';
import { useCandidat } from '@/hooks/use-candidats';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Mail, Phone, MapPin, Calendar, Award } from 'lucide-react';
import { formatDate, formatPhoneNumber, getStatusColor, getStatusLabel } from '@/lib/utils';
import Link from 'next/link';

export default function CandidatDetailContent() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id ? parseInt(params.id as string) : undefined;

  const { data: candidat, isLoading, error } = useCandidat(id || 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (error || !candidat) {
    return (
      <div className="space-y-4">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour
        </Button>
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">Candidat non trouvé</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-bold">
          {candidat.name.firstName} {candidat.name.lastName}
        </h1>
        <Badge className={getStatusColor(candidat.status)}>
          {getStatusLabel(candidat.status)}
        </Badge>
      </div>

      {/* Informations Personnelles */}
      <Card>
        <CardHeader>
          <CardTitle>Informations Personnelles</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-sm font-medium text-gray-600">Nom</label>
              <p className="text-lg">{candidat.name.lastName}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Prénom</label>
              <p className="text-lg">{candidat.name.firstName}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Date de Naissance
              </label>
              <p className="text-lg">{formatDate(candidat.birthDate)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Lieu de Naissance</label>
              <p className="text-lg">{candidat.placeOfBirth || '-'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Téléphone
              </label>
              <p className="text-lg">{formatPhoneNumber(candidat.phoneNumber)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Genre</label>
              <p className="text-lg">{candidat.gender ? (candidat.gender === 'MALE' ? 'Homme' : 'Femme') : '-'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Adresse */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Adresse
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg">{candidat.address}</p>
        </CardContent>
      </Card>

      {/* Informations Inscription */}
      <Card>
        <CardHeader>
          <CardTitle>Informations d&apos;Inscription</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-sm font-medium text-gray-600">N° Inscription</label>
              <p className="font-mono text-lg">{candidat.inscriptionId}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Date Inscription</label>
              <p className="text-lg">{candidat.inscriptionDate ? formatDate(candidat.inscriptionDate) : '-'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Award className="h-4 w-4" />
                Permis Demandé
              </label>
              <Badge className="bg-blue-100 text-blue-800">{candidat.requestedLicense}</Badge>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Permis Possédés</label>
              <div className="flex gap-2 mt-2">
                {(candidat.ownedLicense && candidat.ownedLicense.length > 0) ? (
                  candidat.ownedLicense.map((license) => (
                    <Badge key={license} className="bg-green-100 text-green-800">
                      {license}
                    </Badge>
                  ))
                ) : (
                  <span className="text-gray-500">Aucun</span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Parents */}
      <Card>
        <CardHeader>
          <CardTitle>Informations Familiales</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-sm font-medium text-gray-600">Père</label>
              <p className="text-lg">
                {candidat.fatherName
                  ? `${candidat.fatherName.firstName} ${candidat.fatherName.lastName}`
                  : '-'}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Mère</label>
              <p className="text-lg">
                {candidat.motherName
                  ? `${candidat.motherName.firstName} ${candidat.motherName.lastName}`
                  : '-'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Boutons Action */}
      <div className="flex gap-4">
        <Link href="/candidats">
          <Button variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste
          </Button>
        </Link>
      </div>
    </div>
  );
}
