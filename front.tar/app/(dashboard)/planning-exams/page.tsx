'use client';

import { Suspense } from 'react';
import dynamic from 'next/dynamic';

const PlanningExamsContent = dynamic(() => import('@/components/exams/PlanningExamsContent'), {
  loading: () => <div className="text-center py-8">Chargement du planning...</div>,
  ssr: false,
});

export default function PlanningExamsPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Planning des Examens</h1>
      </div>
      <Suspense fallback={<div>Chargement...</div>}>
        <PlanningExamsContent />
      </Suspense>
    </div>
  );
}
