'use client';

import { Suspense } from 'react';
import dynamic from 'next/dynamic';

const CandidatsNonFiniContent = dynamic(() => import('@/components/candidats/CandidatsNonFiniContent'), {
  loading: () => <div className="text-center py-8">Chargement...</div>,
  ssr: false,
});

export default function CandidatsNonFiniPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Candidats - Dossiers à compléter</h1>
      </div>
      <Suspense fallback={<div>Chargement...</div>}>
        <CandidatsNonFiniContent />
      </Suspense>
    </div>
  );
}
