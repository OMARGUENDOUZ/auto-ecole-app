'use client';

import { useState, useMemo } from 'react';
import { useExams } from '@/hooks/use-exams';
import { useCandidats } from '@/hooks/use-candidats';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar as CalendarIcon, List, ChevronLeft, ChevronRight } from 'lucide-react';
import { Exam, ExamStatus, ExamCategory } from '@/types/exam';
import { formatDate } from '@/lib/utils';
import {
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  format,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
} from 'date-fns';
import { fr } from 'date-fns/locale';

export default function PlanningExamsContent() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const [filterStatus, setFilterStatus] = useState<ExamStatus | 'all'>('all');

  const { data: exams = [], isLoading: loadingExams } = useExams();
  const { data: candidats = [], isLoading: loadingCandidats } = useCandidats();

  const filteredExams = useMemo(() => {
    return (exams || []).filter((exam) => {
      if (filterStatus !== 'all' && exam.status !== filterStatus) {
        return false;
      }
      if (!exam.date) return false;
      
      const examDate = new Date(exam.date);
      const monthStart = startOfMonth(currentDate);
      const monthEnd = endOfMonth(currentDate);
      
      return examDate >= monthStart && examDate <= monthEnd;
    });
  }, [exams, filterStatus, currentDate]);

  const getCandidatName = (studentId: number) => {
    const candidat = (candidats || []).find((c) => c.id === studentId);
    return candidat
      ? `${candidat.name.firstName} ${candidat.name.lastName}`
      : 'Inconnu';
  };

  const getExamsByDate = (date: Date) => {
    return (filteredExams || []).filter((exam) =>
      isSameDay(new Date(exam.date!), date)
    );
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { locale: fr });
  const calendarEnd = endOfWeek(monthEnd, { locale: fr });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const getStatusColor = (status: ExamStatus) => {
    const colors: Record<string, string> = {
      NOT_PLANNED: 'bg-gray-100 text-gray-800',
      PLANNED: 'bg-blue-100 text-blue-800',
      SCHEDULED: 'bg-purple-100 text-purple-800',
      CANCELLED: 'bg-red-100 text-red-800',
      PASSED: 'bg-green-100 text-green-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getCategoryColor = (category: ExamCategory) => {
    return category === ExamCategory.CODE
      ? 'bg-yellow-100 text-yellow-800'
      : 'bg-blue-100 text-blue-800';
  };

  if (loadingExams || loadingCandidats) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <p className="text-gray-600 mt-1">
            {(filteredExams || []).length} examen{(filteredExams || []).length > 1 ? 's' : ''} ce mois
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Filter Status */}
          <Select
            value={filterStatus}
            onValueChange={(value) => setFilterStatus(value as ExamStatus | 'all')}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrer par statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value={ExamStatus.SCHEDULED}>Programmé</SelectItem>
              <SelectItem value={ExamStatus.PLANNED}>Planifié</SelectItem>
              <SelectItem value={ExamStatus.PASSED}>Passé</SelectItem>
              <SelectItem value={ExamStatus.CANCELLED}>Annulé</SelectItem>
            </SelectContent>
          </Select>

          {/* Toggle View */}
          <div className="flex items-center border rounded-lg p-1">
            <Button
              variant={viewMode === 'calendar' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('calendar')}
            >
              <CalendarIcon className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Mois */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentDate(subMonths(currentDate, 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <h2 className="text-xl font-semibold">
              {format(currentDate, 'MMMM yyyy', { locale: fr })}
            </h2>

            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentDate(addMonths(currentDate, 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Content */}
      {viewMode === 'calendar' ? (
        <Card>
          <CardContent className="p-6">
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {/* Headers Jours */}
              {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map((day) => (
                <div
                  key={day}
                  className="text-center font-semibold text-sm text-gray-600 py-2"
                >
                  {day}
                </div>
              ))}

              {/* Days */}
              {calendarDays.map((day, index) => {
                const dayExams = getExamsByDate(day);
                const isCurrentMonth = day >= monthStart && day <= monthEnd;
                const isToday = isSameDay(day, new Date());

                return (
                  <div
                    key={index}
                    className={`min-h-[100px] border rounded-lg p-2 ${
                      !isCurrentMonth ? 'bg-gray-50' : 'bg-white'
                    } ${isToday ? 'ring-2 ring-primary' : ''}`}
                  >
                    <div
                      className={`text-sm font-medium mb-1 ${
                        !isCurrentMonth ? 'text-gray-400' : 'text-gray-900'
                      }`}
                    >
                      {format(day, 'd')}
                    </div>

                    <div className="space-y-1">
                      {dayExams.slice(0, 3).map((exam) => (
                        <div
                          key={exam.id}
                          className={`text-xs p-1 rounded truncate ${getCategoryColor(
                            exam.category
                          )}`}
                          title={getCandidatName(exam.studentId)}
                        >
                          {exam.date && format(new Date(exam.date), 'HH:mm')}{' '}
                          {getCandidatName(exam.studentId).split(' ')[0]}
                        </div>
                      ))}
                      {dayExams.length > 3 && (
                        <div className="text-xs text-gray-500">
                          +{dayExams.length - 3} autre{dayExams.length - 3 > 1 ? 's' : ''}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Liste des Examens</CardTitle>
          </CardHeader>
          <CardContent>
            {(filteredExams || []).length === 0 ? (
              <p className="text-center text-gray-500 py-8">
                Aucun examen trouvé pour ce mois
              </p>
            ) : (
              <div className="space-y-3">
                {(filteredExams || [])
                  .sort(
                    (a, b) =>
                      new Date(a.date!).getTime() - new Date(b.date!).getTime()
                  )
                  .map((exam) => (
                    <div
                      key={exam.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <p className="font-medium">
                            {getCandidatName(exam.studentId)}
                          </p>
                          <Badge className={getCategoryColor(exam.category)}>
                            {exam.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          {exam.date &&
                            format(new Date(exam.date), 'EEEE dd MMMM yyyy à HH:mm', {
                              locale: fr,
                            })}
                        </p>
                      </div>
                      <Badge className={getStatusColor(exam.status)}>
                        {exam.status}
                      </Badge>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Légende */}
      <Card>
        <CardHeader>
          <CardTitle>Légende</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-yellow-100" />
              <span className="text-sm">Examen Code</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-blue-100" />
              <span className="text-sm">Examen Conduite</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-purple-100" />
              <span className="text-sm">Programmé</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-green-100" />
              <span className="text-sm">Passé</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
