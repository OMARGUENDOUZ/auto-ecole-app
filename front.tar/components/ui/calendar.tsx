import * as React from "react"

export const Calendar = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={className} {...props}>
    Calendrier
  </div>
))
Calendar.displayName = "Calendar"

export { Calendar as default }
