export enum ExamStatus {
  NOT_PLANNED = 'NOT_PLANNED',
  PLANNED = 'PLANNED',
  SCHEDULED = 'SCHEDULED',
  CANCELLED = 'CANCELLED',
  PASSED = 'PASSED'
}

export enum ExamCategory {
  CODE = 'CODE',
  CONDUITE = 'CONDUITE'
}

export enum ExamResult {
  PASS = 'PASS',
  FAIL = 'FAIL',
  PENDING = 'PENDING'
}

export interface Exam {
  id: number;
  studentId: number;
  category: ExamCategory;
  status: ExamStatus;
  result?: ExamResult;
  date?: string;
}
