import { Button, buttonVariants } from '@/components/ui/button';
export { Button, buttonVariants };
export default Button;
