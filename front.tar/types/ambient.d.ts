declare module '@/components/ui/button' {
  export * from '@/components/ui/button';
}
declare module '@/components/ui/input' {
  export * from '@/components/ui/input';
}
declare module '@/components/ui/card' {
  export * from '@/components/ui/card';
}
declare module '@/hooks/use-candidats' {
  export * from '@/hooks/use-candidats';
}
declare module '@/hooks/use-exams' {
  export * from '@/hooks/use-exams';
}
